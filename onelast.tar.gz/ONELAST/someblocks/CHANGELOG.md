## [1.0.1] - 2022-12-11
### Fixed
- Fixed crashes due to bad signal handling

## [1.0.0] - 2022-04-20
Initial release
